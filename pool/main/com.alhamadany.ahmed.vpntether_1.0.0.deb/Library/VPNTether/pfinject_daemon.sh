#!/var/jb/usr/bin/bash
export PATH=/var/jb/usr/bin:/var/jb/usr/sbin:/var/jb/sbin:/var/jb/bin:/usr/bin:/bin:/usr/sbin:/sbin

LOG="/var/jb/usr/local/libexec/pf_hook/inject_daemon.log"
PIDFILE="/var/jb/usr/local/libexec/pf_hook/injected.pid"
INJECT_BIN="/var/jb/basebin/opainject"
DYLIB="/var/jb/usr/local/libexec/pf_hook/pf_hook.dylib"

log() {
    echo "$(date) $1" >> "$LOG"
}

fix_mtu() {
    local mtu
    mtu=$(ifconfig utun5 2>/dev/null | sed -n 's/.*mtu \([0-9]*\).*/\1/p')
    if [ -z "$mtu" ]; then
        return
    fi
    if [ "$mtu" != "1450" ]; then
        ifconfig utun5 mtu 1450 2>/dev/null
        local new_mtu
        new_mtu=$(ifconfig utun5 2>/dev/null | sed -n 's/.*mtu \([0-9]*\).*/\1/p')
        log "MTU FIX: $mtu -> $new_mtu"
    fi
}

tune_network() {
    log "Tuning network..."
    sysctl -w net.inet.tcp.sendspace=262144 >/dev/null 2>&1
    sysctl -w net.inet.tcp.recvspace=262144 >/dev/null 2>&1
    sysctl -w net.inet.tcp.autosndbufmax=8388604 >/dev/null 2>&1
    sysctl -w net.inet.tcp.autorcvbufmax=8388604 >/dev/null 2>&1
    sysctl -w net.inet.tcp.mssdflt=1410 >/dev/null 2>&1
    sysctl -w net.inet.tcp.win_scale_factor=4 >/dev/null 2>&1
    sysctl -w net.inet.tcp.delayed_ack=0 >/dev/null 2>&1
    sysctl -w net.inet.tcp.cubic_tcp_friendliness=1 >/dev/null 2>&1
    sysctl -w net.inet.tcp.cubic_fast_convergence=1 >/dev/null 2>&1
    sysctl -w net.inet.tcp.maxseg_unacked=16 >/dev/null 2>&1
    sysctl -w net.inet.tcp.pmtud_blackhole_detection=0 >/dev/null 2>&1
    log "Tuning done"
}

log "=== daemon v2 started ==="
tune_network

LAST_MISD_PID=""
TUNE_COUNTER=0

while true; do
    fix_mtu

    TUNE_COUNTER=$((TUNE_COUNTER + 1))
    if [ "$TUNE_COUNTER" -ge 12 ]; then
        TUNE_COUNTER=0
        tune_network
    fi

    MISD_PID=""
    for pid in $(ps -A -o pid=,comm= 2>/dev/null | grep '[m]isd' | awk '{print $1}'); do
        MISD_PID="$pid"
        break
    done

    if [ -z "$MISD_PID" ]; then
        if [ -n "$LAST_MISD_PID" ]; then
            log "misd exited, waiting..."
            LAST_MISD_PID=""
            rm -f "$PIDFILE"
        fi
        sleep 0.5
        continue
    fi

    if [ "$MISD_PID" = "$LAST_MISD_PID" ]; then
        sleep 0.5
        continue
    fi

    log "misd PID=$MISD_PID, injecting..."
    rm -f /var/jb/usr/local/libexec/pf_hook/hook.log

    "$INJECT_BIN" "$MISD_PID" "$DYLIB" >> "$LOG" 2>&1
    EXIT=$?

    if [ "$EXIT" -eq 0 ]; then
        log "inject OK pid=$MISD_PID"
        echo "$MISD_PID" > "$PIDFILE"
        LAST_MISD_PID="$MISD_PID"
        sleep 1
        if [ -f /var/jb/usr/local/libexec/pf_hook/hook.log ]; then
            log "hook OK: $(wc -c < /var/jb/usr/local/libexec/pf_hook/hook.log) bytes"
        else
            log "hook.log missing"
        fi
    else
        log "inject FAIL pid=$MISD_PID exit=$EXIT"
        sleep 2
    fi
done
